# RAG (Retrieval-Augmented Generation) System

A complete RAG pipeline: document/dataset ingestion → chunking → pretrained
embeddings → FAISS vector store → dense or hybrid (BM25 + vector) retrieval
→ optional re-ranking → LLM answer generation. Includes a validation harness
and system metrics reporting.

## Architecture

```
Documents (PDF/TXT) or HF dataset archive (jsonl/csv/parquet/Hub)
      |
      v
1. Document Ingestion        rag/document_loader.py
      |
      v
2. Text Chunking              rag/chunker.py
      |
      v
3. Embedding Creation         rag/embeddings.py        (pretrained model, dim 384)
      |
      v
4. Vector Database            rag/vector_store.py       (FAISS IndexFlatIP)
      |
User Question
      |
      v
5. Query Embedding            rag/embeddings.py (called from vector_store.query)
      |
      v
6. Context Retrieval          rag/vector_store.py  or  rag/hybrid_search.py (BM25+vector, RRF)
      |
   6b. Re-ranking (optional)  rag/reranker.py       (cross-encoder)
      |
      v
7. Answer Generation          rag/generator.py       (Claude, grounded in retrieved context)
      |
      v
   Final Answer
```

## Pretrained models & offline fallback

- **Embeddings**: `sentence-transformers/all-MiniLM-L6-v2` (384-dim).
- **Re-ranker**: `cross-encoder/ms-marco-MiniLM-L-6-v2`.
- **Generator**: Claude (`claude-sonnet-4-6`) via the Anthropic API.

Both pretrained models require downloading from the Hugging Face Hub the
first time they run. If the Hub is unreachable (offline machine,
network-restricted sandbox, firewall), `rag/embeddings.py` and
`rag/reranker.py` **automatically detect this and fall back** to a local
TF-IDF+SVD embedding and a lexical word-overlap re-ranker, respectively —
so the pipeline still runs end to end. Every fallback is logged explicitly
and reported in `system_metrics()` / the metrics report
(`is_pretrained_neural_model: true|false`), so results are never silently
misrepresented as coming from the pretrained model when they didn't. In an
environment with internet access, no code changes are needed — the real
pretrained models are used automatically.

## Project structure

```
rag_project/
├── rag/
│   ├── document_loader.py   # Stage 1: PDFs, text files, HF dataset archives (local or Hub)
│   ├── chunker.py            # Stage 2: sentence-aware chunking with overlap
│   ├── embeddings.py         # Stage 3: pretrained embedding model + offline fallback
│   ├── vector_store.py       # Stage 4/6: FAISS index + similarity search
│   ├── hybrid_search.py      # Stage 6 (optimization): BM25 + vector fusion (RRF)
│   ├── reranker.py           # Stage 6b (optimization): cross-encoder re-ranking + fallback
│   ├── generator.py          # Stage 7: LLM answer generation (+ extractive fallback)
│   └── pipeline.py           # Orchestrates all stages, exposes system_metrics()
├── scripts/
│   ├── run_demo.py                 # Deliverable 1: operational end-to-end Q&A demo
│   ├── run_validation.py           # Deliverable 2: retrieval validation + logs
│   └── generate_metrics_report.py  # Deliverable 3: system metrics report
├── logs/                     # Generated validation logs & metrics reports land here
├── sample_docs/              # Example .txt files + a domain_archive.jsonl "HF-format" archive
├── main.py                   # Interactive CLI
├── requirements.txt
└── README.md
```

## Setup

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY="your-key-here"   # optional: enables full LLM-generated answers
```

## Usage

**Interactive demo** on the bundled sample documents:
```bash
python main.py --docs sample_docs
```

**Your own documents**, hybrid retrieval + re-ranking:
```bash
python main.py --docs path/to/your/documents --retrieval_mode hybrid --rerank
```

**A Hugging Face dataset** straight from the Hub (requires internet):
```bash
python main.py --hf_dataset squad --text_field context --limit 200
```

**A local domain-specific dataset archive** (jsonl/csv/parquet) — just drop
it in the folder passed to `--docs`; it's auto-detected alongside PDFs/text
files (see `sample_docs/domain_archive.jsonl`).

**Programmatic use**:
```python
from rag import RAGPipeline

pipeline = RAGPipeline(chunk_size=500, overlap=50, top_k=3,
                        retrieval_mode="hybrid", use_reranker=True)
pipeline.ingest_folder("sample_docs")

result = pipeline.ask("What does Reciprocal Rank Fusion do?")
print(result["answer"])
print(result["retrieved_chunks"])
print(result["timing"])
print(pipeline.system_metrics())
```

## Deliverables

### 1. Operational end-to-end pipeline
```bash
python scripts/run_demo.py
```
Prints grounded, context-aware answers (with source + relevance score) for
a set of custom-domain questions. Output captured in `logs/demo_run_output.txt`.

### 2. Validation logs
```bash
python scripts/run_validation.py
```
Runs a set of dynamic sample questions with known-correct source documents
against three configurations (vector-only, hybrid, hybrid+rerank), computes
Recall@k and retrieval latency for each, and writes a timestamped report to
`logs/validation_log.md`. Current run: **100% Recall@3** on all three
configurations against the bundled sample corpus.

### 3. System metrics report
```bash
python scripts/generate_metrics_report.py
```
Writes `logs/system_metrics_report.md` (+ raw JSON) detailing, per
configuration: chunking profile (chunk size, overlap, chunk count, avg/min/max
chunk length), embedding model + dimension + whether it's the pretrained
neural model or the offline fallback, vector store tool/index type, retrieval
mode, re-ranker setup, and LLM generator setup.

## Optimization experiments (Stage 8)

- **Chunk boundaries**: `--chunk_size` / `--overlap` (or the `RAGPipeline`
  constructor args) — try smaller chunks for precision-heavy corpora, larger
  chunks with more overlap for narrative/context-heavy text.
- **Hybrid search**: `--retrieval_mode hybrid` fuses BM25 keyword search with
  dense vector search via Reciprocal Rank Fusion (`rag/hybrid_search.py`),
  which helps on queries containing exact names/codes that embeddings can
  underweight.
- **Re-ranking**: `--rerank` adds a cross-encoder (or lexical-overlap
  fallback) second-pass re-ranker (`rag/reranker.py`) over a wider initial
  candidate set for better final precision.

Re-run `scripts/run_validation.py` after changing any of these to see the
effect on Recall@k and latency in the generated log.
