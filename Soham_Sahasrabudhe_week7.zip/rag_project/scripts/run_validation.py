"""
scripts/run_validation.py
--------------------------
Deliverable #2: Documented validation logs showing retrieval performance
against dynamic sample questions.

For each test question we know which source document should be retrieved
(a "gold" label). We run the pipeline, check whether the gold source shows
up in the top-k retrieved chunks (hit rate / recall@k), and write a
timestamped Markdown log to logs/validation_log.md.

Run:
    python scripts/run_validation.py
"""

import sys
import os
import time
import logging
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rag import RAGPipeline

logging.basicConfig(level=logging.WARNING)  # keep console clean; details go to the log file

# Dynamic sample questions with the source document each answer should come from.
TEST_CASES = [
    {"question": "What are the three core stages of a RAG pipeline?", "expected_source": "rag_notes.txt"},
    {"question": "Why does chunk size matter for retrieval quality?", "expected_source": "rag_notes.txt"},
    {"question": "What is an embedding and why is it useful for search?", "expected_source": "embeddings_basics.txt"},
    {"question": "What does cosine similarity measure?", "expected_source": "embeddings_basics.txt"},
    {"question": "What is the tradeoff between TF-IDF and neural embedding models?", "expected_source": "embeddings_basics.txt"},
    {"question": "What does Reciprocal Rank Fusion do?", "expected_source": "domain_archive.jsonl"},
    {"question": "Why is BM25 useful alongside vector search?", "expected_source": "domain_archive.jsonl"},
    {"question": "How does a cross-encoder re-ranker work?", "expected_source": "domain_archive.jsonl"},
    {"question": "What FAISS index type supports fast approximate search on large corpora?", "expected_source": "domain_archive.jsonl"},
]

CONFIGS = [
    {"name": "vector-only", "retrieval_mode": "vector", "use_reranker": False},
    {"name": "hybrid", "retrieval_mode": "hybrid", "use_reranker": False},
    {"name": "hybrid+rerank", "retrieval_mode": "hybrid", "use_reranker": True},
]


def hit_at_k(expected_source: str, retrieved_chunks, k: int) -> bool:
    """
    expected_source may be an exact filename ('rag_notes.txt') or, for
    dataset-archive records, a prefix ('domain_archive.jsonl') that should
    match per-record sources like 'domain_archive.jsonl#1'.
    """
    top_k_sources = [c.source for c, _ in retrieved_chunks[:k]]
    return any(s == expected_source or s.startswith(expected_source + "#") for s in top_k_sources)


def run_validation(docs_folder="sample_docs", top_k=3, log_path="logs/validation_log.md"):
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [f"# Validation Log", f"Run at: {timestamp}", f"Documents folder: `{docs_folder}`", ""]
    summary_rows = []

    for config in CONFIGS:
        print(f"\n=== Config: {config['name']} ===")
        pipeline = RAGPipeline(
            chunk_size=400, overlap=50, top_k=top_k,
            retrieval_mode=config["retrieval_mode"], use_reranker=config["use_reranker"],
            verbose=False,
        )
        pipeline.ingest_folder(docs_folder)

        lines.append(f"## Config: {config['name']}")
        lines.append(
            f"- retrieval_mode=`{config['retrieval_mode']}`, "
            f"use_reranker=`{config['use_reranker']}`, top_k=`{top_k}`"
        )
        lines.append(f"- embedding backend: `{pipeline.embedding_model.backend}`")
        lines.append("")
        lines.append("| # | Question | Expected source | Hit@k | Top retrieved source | Score | Retrieval time (s) |")
        lines.append("|---|----------|------------------|-------|------------------------|-------|---------------------|")

        hits = 0
        total_retrieval_time = 0.0
        for i, case in enumerate(TEST_CASES, start=1):
            result = pipeline.ask(case["question"], top_k=top_k)
            retrieved = result["retrieved_chunks"]
            hit = hit_at_k(case["expected_source"], retrieved, top_k)
            hits += int(hit)
            retrieval_time = result["timing"]["retrieval_seconds"]
            total_retrieval_time += retrieval_time

            q_escaped = case["question"].replace("|", "\\|")
            if retrieved:
                top_source = retrieved[0][0].source
                top_score = f"{retrieved[0][1]:.3f}"
            else:
                top_source = "(none)"
                top_score = "-"

            lines.append(
                f"| {i} | {q_escaped} | {case['expected_source']} | {'YES' if hit else 'NO'} | "
                f"{top_source} | {top_score} | {retrieval_time:.4f} |"
            )

        recall_at_k = hits / len(TEST_CASES)
        avg_retrieval_time = total_retrieval_time / len(TEST_CASES)
        lines.append("")
        lines.append(f"**Recall@{top_k}: {hits}/{len(TEST_CASES)} = {recall_at_k:.1%}**  ")
        lines.append(f"**Avg retrieval time: {avg_retrieval_time*1000:.2f} ms**")
        lines.append("")

        summary_rows.append((config["name"], recall_at_k, avg_retrieval_time, pipeline.embedding_model.backend))
        print(f"Recall@{top_k}: {hits}/{len(TEST_CASES)} = {recall_at_k:.1%}")

    lines.append("## Summary")
    lines.append("| Config | Recall@k | Avg retrieval time (ms) | Embedding backend |")
    lines.append("|--------|----------|---------------------------|--------------------|")
    for name, recall, t, backend in summary_rows:
        lines.append(f"| {name} | {recall:.1%} | {t*1000:.2f} | {backend} |")

    with open(log_path, "w") as f:
        f.write("\n".join(lines))

    print(f"\nValidation log written to {log_path}")
    return summary_rows


if __name__ == "__main__":
    run_validation()
