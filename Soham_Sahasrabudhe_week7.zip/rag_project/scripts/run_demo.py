"""
scripts/run_demo.py
--------------------
Deliverable #1: An operational end-to-end question-answering pipeline
that prints grounded, context-aware answers to custom-domain queries.

Run:
    python scripts/run_demo.py
"""

import sys
import os
import logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rag import RAGPipeline

logging.basicConfig(level=logging.INFO, format="%(message)s")

DEMO_QUESTIONS = [
    "What are the three core stages of a RAG pipeline?",
    "What is an embedding and why is it useful for search?",
    "What does Reciprocal Rank Fusion do and why is it useful?",
    "How does a cross-encoder re-ranker improve retrieval precision?",
]


def main():
    pipeline = RAGPipeline(
        chunk_size=400, overlap=50, top_k=3,
        retrieval_mode="hybrid", use_reranker=True, verbose=True,
    )
    n = pipeline.ingest_folder("sample_docs")
    print(f"\nIndexed {n} chunks from {pipeline.num_docs} documents/records "
          f"(embedding backend: {pipeline.embedding_model.backend}).\n")
    print("=" * 70)

    for question in DEMO_QUESTIONS:
        result = pipeline.ask(question)
        print(f"\nQ: {question}")
        print(f"A: {result['answer']}")
        print("\nGrounded in:")
        for chunk, score in result["retrieved_chunks"]:
            print(f"  - [{chunk.source}] score={score:.3f}: {chunk.text[:90]}...")
        print(f"\nTiming: {result['timing']}")
        print("=" * 70)


if __name__ == "__main__":
    main()
