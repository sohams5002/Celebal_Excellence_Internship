"""
scripts/generate_metrics_report.py
------------------------------------
Deliverable #3: System metrics report detailing chunking profiles, chosen
embedding dimensions, vector store tooling, and LLM setup.

Run:
    python scripts/generate_metrics_report.py
"""

import sys
import os
import json
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rag import RAGPipeline

CONFIGS = [
    {"name": "vector-only", "retrieval_mode": "vector", "use_reranker": False},
    {"name": "hybrid", "retrieval_mode": "hybrid", "use_reranker": False},
    {"name": "hybrid+rerank", "retrieval_mode": "hybrid", "use_reranker": True},
]


def generate_report(docs_folder="sample_docs", report_path="logs/system_metrics_report.md"):
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "# System Metrics Report",
        f"Generated at: {timestamp}",
        f"Documents folder: `{docs_folder}`",
        "",
        "## Per-configuration metrics",
        "",
    ]

    all_metrics = {}
    for config in CONFIGS:
        pipeline = RAGPipeline(
            chunk_size=400, overlap=50, top_k=3,
            retrieval_mode=config["retrieval_mode"], use_reranker=config["use_reranker"],
            verbose=False,
        )
        pipeline.ingest_folder(docs_folder)
        metrics = pipeline.system_metrics()
        all_metrics[config["name"]] = metrics

        lines.append(f"### {config['name']}")
        lines.append("")
        lines.append("**Chunking profile**")
        for k, v in metrics["chunking"].items():
            lines.append(f"- {k}: `{v}`")
        lines.append("")
        lines.append("**Embedding model**")
        for k, v in metrics["embedding_model"].items():
            lines.append(f"- {k}: `{v}`")
        lines.append("")
        lines.append("**Vector store**")
        for k, v in metrics["vector_store"].items():
            lines.append(f"- {k}: `{v}`")
        lines.append("")
        lines.append(f"**Retrieval mode**: `{metrics['retrieval_mode']}`")
        lines.append("")
        lines.append("**Reranker**")
        for k, v in metrics["reranker"].items():
            lines.append(f"- {k}: `{v}`")
        lines.append("")
        lines.append("**Generator (LLM) setup**")
        for k, v in metrics["generator"].items():
            lines.append(f"- {k}: `{v}`")
        lines.append("")
        lines.append(f"**Index build time**: `{metrics['build_time_seconds']}s`")
        lines.append("")
        lines.append("---")
        lines.append("")

    lines.append("## Raw JSON (all configs)")
    lines.append("```json")
    lines.append(json.dumps(all_metrics, indent=2))
    lines.append("```")

    with open(report_path, "w") as f:
        f.write("\n".join(lines))

    print(f"System metrics report written to {report_path}")
    return all_metrics


if __name__ == "__main__":
    generate_report()
