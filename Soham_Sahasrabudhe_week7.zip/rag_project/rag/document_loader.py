"""
document_loader.py
-------------------
Stage 1 of the RAG pipeline: Document Ingestion.

Loads documents (PDF or plain text) from disk and converts them
into raw text strings that can be passed to the chunker.
"""

import os
from pathlib import Path

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None


def load_text_file(path: str) -> str:
    """Read a plain .txt or .md file and return its contents."""
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def load_pdf_file(path: str) -> str:
    """Extract raw text from a PDF file, page by page."""
    if PdfReader is None:
        raise ImportError("pypdf is required to read PDF files. Install with: pip install pypdf")

    reader = PdfReader(path)
    pages_text = []
    for page in reader.pages:
        text = page.extract_text() or ""
        pages_text.append(text)
    return "\n".join(pages_text)


def load_document(path: str) -> str:
    """
    Load a single document (.txt, .md, or .pdf) and return its raw text.
    Raises ValueError for unsupported file types.
    """
    suffix = Path(path).suffix.lower()
    if suffix in (".txt", ".md"):
        return load_text_file(path)
    elif suffix == ".pdf":
        return load_pdf_file(path)
    else:
        raise ValueError(f"Unsupported file type: {suffix}")


def load_huggingface_dataset(dataset_name: str, text_field: str = "text", split: str = "train",
                              limit: int = None) -> dict:
    """
    Load a domain-specific dataset from the Hugging Face Hub (e.g. a
    community-uploaded corpus of articles, tickets, or QA pairs) and
    return it in the same {doc_id: text} shape as the other loaders.

    Requires network access to huggingface.co. Raises a clear RuntimeError
    if the Hub can't be reached, so callers can fall back to
    `load_local_dataset_archive` for offline/local dataset files instead.
    """
    try:
        from datasets import load_dataset
    except ImportError:
        raise ImportError("The 'datasets' package is required. Install with: pip install datasets")

    try:
        ds = load_dataset(dataset_name, split=split)
    except Exception as e:
        raise RuntimeError(
            f"Could not download dataset '{dataset_name}' from the Hugging Face Hub "
            f"({type(e).__name__}: {e}). If you're offline or network-restricted, use "
            f"load_local_dataset_archive() with a local .jsonl/.csv/.parquet file instead."
        )

    if limit:
        ds = ds.select(range(min(limit, len(ds))))

    documents = {}
    for i, row in enumerate(ds):
        if text_field not in row:
            raise KeyError(f"text_field '{text_field}' not found in dataset columns: {list(row.keys())}")
        documents[f"{dataset_name}#{i}"] = str(row[text_field])
    return documents


def load_local_dataset_archive(path: str, text_field: str = "text") -> dict:
    """
    Load a local dataset archive in Hugging Face `datasets`-compatible
    format (.jsonl, .json, .csv, or .parquet) with no network required.
    This is the offline-friendly counterpart to load_huggingface_dataset,
    useful for domain-specific archives you already have on disk (e.g.
    exported support tickets, a research-paper abstract dump, etc).
    """
    from datasets import load_dataset
    from pathlib import Path

    suffix = Path(path).suffix.lower().lstrip(".")
    fmt_map = {"jsonl": "json", "json": "json", "csv": "csv", "parquet": "parquet"}
    if suffix not in fmt_map:
        raise ValueError(f"Unsupported archive format: {suffix}")

    ds = load_dataset(fmt_map[suffix], data_files=path, split="train")

    documents = {}
    for i, row in enumerate(ds):
        if text_field not in row:
            raise KeyError(f"text_field '{text_field}' not found in archive columns: {list(row.keys())}")
        documents[f"{Path(path).name}#{i}"] = str(row[text_field])
    return documents


def load_documents_from_folder(folder: str) -> dict:
    """
    Load every supported document in a folder.
    Returns a dict mapping {filename: raw_text}.
    """
    documents = {}
    for fname in sorted(os.listdir(folder)):
        fpath = os.path.join(folder, fname)
        suffix = Path(fname).suffix.lower()
        if suffix in (".txt", ".md", ".pdf"):
            try:
                documents[fname] = load_document(fpath)
            except Exception as e:
                print(f"[document_loader] Skipping {fname}: {e}")
        elif suffix in (".jsonl", ".csv", ".parquet"):
            try:
                documents.update(load_local_dataset_archive(fpath))
            except Exception as e:
                print(f"[document_loader] Skipping dataset archive {fname}: {e}")
    return documents
