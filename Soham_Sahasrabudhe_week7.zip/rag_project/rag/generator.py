"""
generator.py
------------
Stage 7 of the RAG pipeline: Answer Generation.

Takes the user's question plus the retrieved context chunks and produces
a final grounded answer.

Two modes are supported:

1. LLM mode (preferred): if an ANTHROPIC_API_KEY environment variable is
   set, the retrieved context is sent to Claude along with the question,
   and Claude generates a natural-language answer grounded in that context.

2. Extractive fallback mode: if no API key is available, the system falls
   back to returning the most relevant retrieved passage(s) directly, so
   the pipeline still works fully offline with no external dependencies.
"""

import os


SYSTEM_PROMPT = (
    "You are a helpful assistant that answers questions using ONLY the "
    "provided context from the user's documents. If the answer cannot be "
    "found in the context, say so clearly instead of guessing. Keep "
    "answers concise and cite which part of the context you used when helpful."
)


def build_prompt(question: str, retrieved_chunks) -> str:
    """Assemble the augmented prompt: question + retrieved context."""
    context_blocks = []
    for i, (chunk, score) in enumerate(retrieved_chunks, start=1):
        context_blocks.append(f"[Passage {i} | source: {chunk.source} | relevance: {score:.2f}]\n{chunk.text}")
    context_str = "\n\n".join(context_blocks) if context_blocks else "(no relevant context found)"

    return (
        f"Context from documents:\n{context_str}\n\n"
        f"Question: {question}\n\n"
        f"Answer the question using only the context above."
    )


def generate_answer(question: str, retrieved_chunks, model: str = "claude-sonnet-4-6") -> str:
    """
    Generate an answer to `question` using the retrieved chunks as context.
    Uses the Anthropic API if ANTHROPIC_API_KEY is set, otherwise falls
    back to a simple extractive answer.
    """
    api_key = os.environ.get("ANTHROPIC_API_KEY")

    if not retrieved_chunks:
        return "I couldn't find anything relevant to that question in the documents."

    if api_key:
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            prompt = build_prompt(question, retrieved_chunks)
            response = client.messages.create(
                model=model,
                max_tokens=500,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text.strip()
        except Exception as e:
            print(f"[generator] LLM call failed ({e}); falling back to extractive answer.")

    return _extractive_fallback(retrieved_chunks)


def _extractive_fallback(retrieved_chunks) -> str:
    """
    No-LLM fallback: return the single most relevant passage as the answer,
    clearly labeled, so the pipeline still demonstrates retrieval-grounded
    answering without requiring an API key.
    """
    best_chunk, best_score = retrieved_chunks[0]
    return (
        f"(Extractive mode -- no ANTHROPIC_API_KEY set, so returning the most "
        f"relevant passage instead of a generated answer)\n\n"
        f"From '{best_chunk.source}' (relevance {best_score:.2f}):\n{best_chunk.text}"
    )
