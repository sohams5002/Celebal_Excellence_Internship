"""
chunker.py
----------
Stage 2 of the RAG pipeline: Text Chunking.

Splits raw document text into smaller overlapping chunks so that
retrieval can operate on focused, semantically coherent pieces of
text rather than entire documents.
"""

import re
from dataclasses import dataclass


@dataclass
class Chunk:
    text: str
    source: str
    chunk_id: int


def _split_into_sentences(text: str):
    """Very lightweight sentence splitter (no external NLP dependency)."""
    text = re.sub(r"\s+", " ", text).strip()
    sentences = re.split(r"(?<=[.!?])\s+", text)
    return [s for s in sentences if s]


def chunk_text(text: str, source: str = "document", chunk_size: int = 500, overlap: int = 50):
    """
    Split text into overlapping chunks of roughly `chunk_size` characters,
    trying to break on sentence boundaries so chunks stay readable.

    Args:
        text: raw document text
        source: name of the originating document (for citation)
        chunk_size: target max characters per chunk
        overlap: number of characters to overlap between consecutive chunks

    Returns:
        List[Chunk]
    """
    sentences = _split_into_sentences(text)
    chunks = []
    current = ""
    chunk_id = 0

    for sentence in sentences:
        if len(current) + len(sentence) + 1 <= chunk_size:
            current = f"{current} {sentence}".strip()
        else:
            if current:
                chunks.append(Chunk(text=current, source=source, chunk_id=chunk_id))
                chunk_id += 1
            # start new chunk, carrying over a bit of overlap from the tail
            tail = current[-overlap:] if overlap and current else ""
            current = f"{tail} {sentence}".strip()

    if current:
        chunks.append(Chunk(text=current, source=source, chunk_id=chunk_id))

    return chunks


def chunk_documents(documents: dict, chunk_size: int = 500, overlap: int = 50):
    """
    Chunk a dict of {filename: raw_text} documents.
    Returns a flat list of Chunk objects across all documents.
    """
    all_chunks = []
    for name, text in documents.items():
        all_chunks.extend(chunk_text(text, source=name, chunk_size=chunk_size, overlap=overlap))
    return all_chunks
