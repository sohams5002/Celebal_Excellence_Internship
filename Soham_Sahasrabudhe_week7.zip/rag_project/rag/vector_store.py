"""
vector_store.py
----------------
Stage 4 of the RAG pipeline: Vector Database.

Initializes a FAISS index, stores chunk embeddings for fast similarity
search, and exposes a query() route that Stage 5/6 (query embedding +
retrieval) call into.

FAISS index type: IndexFlatIP (exact inner-product search). Because all
vectors are L2-normalized before insertion (see embeddings.py), inner
product is equivalent to cosine similarity. IndexFlatIP is exact (not
approximate) which is appropriate for small-to-medium document sets; for
much larger corpora this could be swapped for an approximate index such as
IndexIVFFlat or IndexHNSWFlat without changing the surrounding pipeline.
"""

import faiss
import numpy as np


class VectorStore:
    def __init__(self, embedding_model):
        self.embedding_model = embedding_model
        self.index = None
        self.chunks = []  # index-aligned with the FAISS index

    def build(self, chunks):
        """
        Embed a list of Chunk objects and load them into a FAISS index.
        """
        self.chunks = chunks
        texts = [c.text for c in chunks]

        # LSA fallback backend needs to be fit on the corpus first
        if getattr(self.embedding_model, "backend", None) == "lsa-fallback":
            self.embedding_model.fit(texts)

        vectors = self.embedding_model.encode(texts)
        dim = vectors.shape[1]

        self.index = faiss.IndexFlatIP(dim)
        self.index.add(vectors)

    def query(self, query_text: str, top_k: int = 3):
        """
        Embed the query (Stage 5) and search the FAISS index (Stage 6).

        Returns:
            List[(Chunk, score)] sorted by descending similarity.
        """
        if self.index is None or self.index.ntotal == 0:
            return []

        query_vec = self.embedding_model.encode([query_text])
        scores, indices = self.index.search(query_vec, min(top_k, self.index.ntotal))

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            results.append((self.chunks[idx], float(score)))
        return results

    def info(self) -> dict:
        return {
            "tool": "FAISS",
            "index_type": "IndexFlatIP (exact cosine via normalized inner product)",
            "num_vectors": int(self.index.ntotal) if self.index is not None else 0,
            "dimension": self.index.d if self.index is not None else None,
        }
