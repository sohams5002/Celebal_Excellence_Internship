"""
embeddings.py
-------------
Stage 3 of the RAG pipeline: Embedding Creation.

Maps chunked text strings into dense vector representations using a
pre-trained embedding model (sentence-transformers/all-MiniLM-L6-v2, 384-dim).

Network-restricted fallback:
    If the Hugging Face Hub cannot be reached (no internet access, offline
    sandbox, firewalled environment, etc.), this module automatically falls
    back to a local LSA-style embedding (TF-IDF -> TruncatedSVD) so the
    pipeline still runs end-to-end. This fallback is NOT a pretrained neural
    model -- it is fit on your own corpus -- and every log line and the
    metrics report clearly states which embedding backend is actually in use
    so results are never silently misrepresented.

Usage:
    model = EmbeddingModel()          # tries all-MiniLM-L6-v2 first
    vecs  = model.encode(["text a", "text b"])   # -> np.ndarray [n, dim]
"""

import logging
import numpy as np

logger = logging.getLogger("rag.embeddings")


class EmbeddingModel:
    PRETRAINED_MODEL_NAME = "all-MiniLM-L6-v2"
    PRETRAINED_DIM = 384
    FALLBACK_DIM = 128

    def __init__(self, model_name: str = None, fallback_dim: int = None, verbose: bool = True):
        self.model_name = model_name or self.PRETRAINED_MODEL_NAME
        self.fallback_dim = fallback_dim or self.FALLBACK_DIM
        self.backend = None       # "sentence-transformers" or "lsa-fallback"
        self.dim = None
        self._st_model = None
        self._svd = None
        self._tfidf = None
        self._fit = False
        self._init_backend(verbose)

    def _init_backend(self, verbose: bool):
        try:
            from sentence_transformers import SentenceTransformer
            self._st_model = SentenceTransformer(self.model_name)
            self.backend = "sentence-transformers"
            self.dim = self.PRETRAINED_MODEL_NAME and self._st_model.get_sentence_embedding_dimension()
            if verbose:
                logger.info(f"[embeddings] Loaded pretrained model '{self.model_name}' (dim={self.dim}).")
        except Exception as e:
            self.backend = "lsa-fallback"
            self.dim = self.fallback_dim
            if verbose:
                logger.warning(
                    f"[embeddings] Could not load pretrained model '{self.model_name}' "
                    f"({type(e).__name__}: {e}). Falling back to a local TF-IDF+SVD "
                    f"embedding (dim={self.dim}). This is NOT a pretrained neural model; "
                    f"it is fit on your own corpus. To use real pretrained embeddings, "
                    f"run in an environment with access to huggingface.co."
                )

    def fit(self, texts):
        """Only required for the LSA fallback backend; no-op for sentence-transformers."""
        if self.backend == "lsa-fallback":
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.decomposition import TruncatedSVD

            self._tfidf = TfidfVectorizer(stop_words="english", max_features=20000)
            tfidf_matrix = self._tfidf.fit_transform(texts)
            n_components = min(self.fallback_dim, tfidf_matrix.shape[1] - 1, tfidf_matrix.shape[0] - 1)
            n_components = max(n_components, 2)
            self._svd = TruncatedSVD(n_components=n_components, random_state=42)
            self._svd.fit(tfidf_matrix)
            self.dim = n_components
        self._fit = True

    def encode(self, texts):
        """
        Encode a list of strings into an (n, dim) float32 numpy array,
        L2-normalized so that dot product == cosine similarity.
        """
        if isinstance(texts, str):
            texts = [texts]

        if self.backend == "sentence-transformers":
            vecs = self._st_model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
            return np.asarray(vecs, dtype="float32")

        # lsa-fallback
        if not self._fit:
            raise RuntimeError("EmbeddingModel(lsa-fallback) must be fit() on the corpus before encode().")
        tfidf_vecs = self._tfidf.transform(texts)
        dense = self._svd.transform(tfidf_vecs)
        norms = np.linalg.norm(dense, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return (dense / norms).astype("float32")

    def info(self) -> dict:
        return {
            "backend": self.backend,
            "requested_model": self.model_name,
            "dimension": self.dim,
            "is_pretrained_neural_model": self.backend == "sentence-transformers",
        }
