"""
hybrid_search.py
-----------------
Experiment #1 from the optimization stage: hybrid retrieval combining
keyword search (BM25) with dense vector search, fused via Reciprocal
Rank Fusion (RRF).

BM25 catches exact keyword/term matches (e.g. product codes, names,
numbers) that dense embeddings can sometimes miss. Vector search catches
semantic/paraphrased matches that pure keyword search misses. Combining
both generally improves recall over either method alone.
"""

from rank_bm25 import BM25Okapi


class HybridRetriever:
    def __init__(self, vector_store):
        self.vector_store = vector_store
        self.bm25 = None
        self.chunks = []

    def build(self, chunks):
        self.chunks = chunks
        tokenized = [c.text.lower().split() for c in chunks]
        self.bm25 = BM25Okapi(tokenized)

    def query(self, query_text: str, top_k: int = 3, vector_k: int = 10, keyword_k: int = 10, rrf_k: int = 60):
        """
        Retrieve candidates from both BM25 and vector search, then fuse
        their rankings with Reciprocal Rank Fusion:

            score(chunk) = sum over each ranker of 1 / (rrf_k + rank)

        This avoids having to normalize/compare BM25 scores (unbounded)
        against cosine similarity scores (0-1) directly.
        """
        if self.bm25 is None:
            return []

        # --- keyword ranking ---
        tokenized_query = query_text.lower().split()
        bm25_scores = self.bm25.get_scores(tokenized_query)
        bm25_ranked = sorted(range(len(bm25_scores)), key=lambda i: bm25_scores[i], reverse=True)[:keyword_k]

        # --- vector ranking ---
        vector_results = self.vector_store.query(query_text, top_k=vector_k)
        vector_ranked_idx = [self.chunks.index(chunk) for chunk, _ in vector_results]

        # --- reciprocal rank fusion ---
        fused_scores = {}
        for rank, idx in enumerate(bm25_ranked):
            fused_scores[idx] = fused_scores.get(idx, 0.0) + 1.0 / (rrf_k + rank + 1)
        for rank, idx in enumerate(vector_ranked_idx):
            fused_scores[idx] = fused_scores.get(idx, 0.0) + 1.0 / (rrf_k + rank + 1)

        ranked = sorted(fused_scores.items(), key=lambda kv: kv[1], reverse=True)[:top_k]
        return [(self.chunks[idx], score) for idx, score in ranked]
