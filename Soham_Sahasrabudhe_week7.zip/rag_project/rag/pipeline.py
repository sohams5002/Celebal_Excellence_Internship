"""
pipeline.py
-----------
Orchestrates the full RAG pipeline end to end:

  1. Document Ingestion     (document_loader.py)
  2. Text Chunking          (chunker.py)
  3. Embedding Creation     (embeddings.py)      -- pretrained model + fallback
  4. Vector Database        (vector_store.py)    -- FAISS
  5. Query Embedding        (embeddings.py, called from vector_store.query)
  6. Context Retrieval      (vector_store.py or hybrid_search.py)
     6b. Optional re-ranking (reranker.py)
  7. Answer Generation      (generator.py)
  8. Optimization knobs     (chunk_size/overlap, retrieval_mode, rerank)
"""

import time
import logging

from .document_loader import load_documents_from_folder, load_document, load_huggingface_dataset
from .chunker import chunk_documents
from .embeddings import EmbeddingModel
from .vector_store import VectorStore
from .hybrid_search import HybridRetriever
from .reranker import Reranker
from .generator import generate_answer

logger = logging.getLogger("rag.pipeline")


class RAGPipeline:
    def __init__(self, chunk_size: int = 500, overlap: int = 50, top_k: int = 3,
                 retrieval_mode: str = "vector", use_reranker: bool = False, verbose: bool = True):
        """
        Args:
            chunk_size: target characters per chunk (Stage 2 tuning knob)
            overlap: character overlap between consecutive chunks
            top_k: number of chunks to hand to the generator
            retrieval_mode: "vector" (dense only) or "hybrid" (BM25 + vector via RRF)
            use_reranker: apply a re-ranking pass over the retrieved candidates
        """
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.top_k = top_k
        self.retrieval_mode = retrieval_mode
        self.use_reranker = use_reranker

        self.embedding_model = EmbeddingModel(verbose=verbose)
        self.store = VectorStore(self.embedding_model)
        self.hybrid = HybridRetriever(self.store)
        self.reranker = Reranker(verbose=verbose) if use_reranker else None

        self.num_chunks = 0
        self.num_docs = 0
        self.build_time_seconds = None

    # ---- Stage 1+2+3+4: ingest -> chunk -> embed -> index ----------------

    def ingest_folder(self, folder: str):
        documents = load_documents_from_folder(folder)
        if not documents:
            raise ValueError(f"No supported documents found in {folder}")
        return self.ingest_documents(documents)

    def ingest_files(self, file_paths):
        documents = {}
        for path in file_paths:
            documents[path.split("/")[-1]] = load_document(path)
        return self.ingest_documents(documents)

    def ingest_huggingface_dataset(self, dataset_name: str, text_field: str = "text",
                                    split: str = "train", limit: int = None):
        documents = load_huggingface_dataset(dataset_name, text_field=text_field, split=split, limit=limit)
        return self.ingest_documents(documents)

    def ingest_documents(self, documents: dict):
        start = time.time()
        self.num_docs = len(documents)

        chunks = chunk_documents(documents, chunk_size=self.chunk_size, overlap=self.overlap)
        self.store.build(chunks)
        self.hybrid.build(chunks)
        self.num_chunks = len(chunks)

        self.build_time_seconds = round(time.time() - start, 3)
        logger.info(
            f"[pipeline] Indexed {self.num_chunks} chunks from {self.num_docs} document(s) "
            f"in {self.build_time_seconds}s (embedding backend: {self.embedding_model.backend})."
        )
        return self.num_chunks

    # ---- Stage 5+6+6b+7: query -> retrieve -> (rerank) -> generate -------

    def ask(self, question: str, top_k: int = None):
        k = top_k or self.top_k
        t0 = time.time()

        if self.retrieval_mode == "hybrid":
            candidate_k = k * 4 if self.use_reranker else k
            retrieved = self.hybrid.query(question, top_k=candidate_k)
        else:
            candidate_k = k * 4 if self.use_reranker else k
            retrieved = self.store.query(question, top_k=candidate_k)

        retrieval_time = time.time() - t0

        rerank_time = None
        if self.use_reranker and retrieved:
            t1 = time.time()
            retrieved = self.reranker.rerank(question, retrieved, top_k=k)
            rerank_time = time.time() - t1
        else:
            retrieved = retrieved[:k]

        t2 = time.time()
        answer = generate_answer(question, retrieved)
        generation_time = time.time() - t2

        return {
            "question": question,
            "answer": answer,
            "retrieved_chunks": retrieved,
            "timing": {
                "retrieval_seconds": round(retrieval_time, 4),
                "rerank_seconds": round(rerank_time, 4) if rerank_time is not None else None,
                "generation_seconds": round(generation_time, 4),
            },
        }

    # ---- Stage 8: system metrics / config summary -------------------------

    def system_metrics(self) -> dict:
        chunk_lengths = [len(c.text) for c in self.store.chunks]
        return {
            "chunking": {
                "chunk_size_target_chars": self.chunk_size,
                "overlap_chars": self.overlap,
                "num_documents": self.num_docs,
                "num_chunks": self.num_chunks,
                "avg_chunk_length_chars": round(sum(chunk_lengths) / len(chunk_lengths), 1) if chunk_lengths else 0,
                "min_chunk_length_chars": min(chunk_lengths) if chunk_lengths else 0,
                "max_chunk_length_chars": max(chunk_lengths) if chunk_lengths else 0,
            },
            "embedding_model": self.embedding_model.info(),
            "vector_store": self.store.info(),
            "retrieval_mode": self.retrieval_mode,
            "reranker": self.reranker.info() if self.reranker else {"enabled": False},
            "build_time_seconds": self.build_time_seconds,
            "generator": {
                "llm_provider": "Anthropic",
                "model": "claude-sonnet-4-6",
                "max_tokens": 500,
                "fallback_mode": "extractive (top passage) if ANTHROPIC_API_KEY is unset",
            },
        }
