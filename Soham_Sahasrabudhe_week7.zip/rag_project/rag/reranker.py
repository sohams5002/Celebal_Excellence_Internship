"""
reranker.py
-----------
Experiment #2 from the optimization stage: a re-ranking layer applied on
top of the initial retrieval results.

Initial retrieval (vector or hybrid) is optimized for recall over the
whole corpus using a fast bi-encoder / BM25. A re-ranker then does a more
expensive, more accurate pairwise (query, chunk) scoring pass over just
the small candidate set to improve final precision -- this two-stage
"retrieve then re-rank" pattern is standard in production RAG systems.

Like embeddings.py, this tries to load a real pretrained cross-encoder
(cross-encoder/ms-marco-MiniLM-L-6-v2) and falls back to a lightweight
lexical-overlap re-ranker if the Hugging Face Hub is unreachable, always
logging which one is actually active.
"""

import logging
import re

logger = logging.getLogger("rag.reranker")


class Reranker:
    CROSS_ENCODER_NAME = "cross-encoder/ms-marco-MiniLM-L-6-v2"

    def __init__(self, verbose: bool = True):
        self.backend = None
        self._model = None
        self._init_backend(verbose)

    def _init_backend(self, verbose: bool):
        try:
            from sentence_transformers import CrossEncoder
            self._model = CrossEncoder(self.CROSS_ENCODER_NAME)
            self.backend = "cross-encoder"
            if verbose:
                logger.info(f"[reranker] Loaded pretrained cross-encoder '{self.CROSS_ENCODER_NAME}'.")
        except Exception as e:
            self.backend = "lexical-overlap-fallback"
            if verbose:
                logger.warning(
                    f"[reranker] Could not load cross-encoder '{self.CROSS_ENCODER_NAME}' "
                    f"({type(e).__name__}: {e}). Falling back to a lexical word-overlap "
                    f"re-ranker. To use the real pretrained cross-encoder, run in an "
                    f"environment with access to huggingface.co."
                )

    def rerank(self, query: str, candidates, top_k: int = 3):
        """
        candidates: List[(Chunk, score)] from initial retrieval.
        Returns: List[(Chunk, rerank_score)] re-sorted, truncated to top_k.
        """
        if not candidates:
            return []

        if self.backend == "cross-encoder":
            pairs = [(query, chunk.text) for chunk, _ in candidates]
            scores = self._model.predict(pairs)
            reranked = sorted(zip([c for c, _ in candidates], scores), key=lambda cs: cs[1], reverse=True)
            return [(c, float(s)) for c, s in reranked[:top_k]]

        # lexical-overlap-fallback: score = fraction of query terms present in chunk
        query_terms = set(re.findall(r"\w+", query.lower()))
        scored = []
        for chunk, _orig_score in candidates:
            chunk_terms = set(re.findall(r"\w+", chunk.text.lower()))
            overlap = len(query_terms & chunk_terms) / max(len(query_terms), 1)
            scored.append((chunk, overlap))
        scored.sort(key=lambda cs: cs[1], reverse=True)
        return scored[:top_k]

    def info(self) -> dict:
        return {
            "backend": self.backend,
            "requested_model": self.CROSS_ENCODER_NAME,
            "is_pretrained_neural_model": self.backend == "cross-encoder",
        }
