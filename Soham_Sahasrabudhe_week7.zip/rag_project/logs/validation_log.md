# Validation Log
Run at: 2026-08-02 18:45:51
Documents folder: `sample_docs`

## Config: vector-only
- retrieval_mode=`vector`, use_reranker=`False`, top_k=`3`
- embedding backend: `lsa-fallback`

| # | Question | Expected source | Hit@k | Top retrieved source | Score | Retrieval time (s) |
|---|----------|------------------|-------|------------------------|-------|---------------------|
| 1 | What are the three core stages of a RAG pipeline? | rag_notes.txt | YES | rag_notes.txt | 0.975 | 0.0011 |
| 2 | Why does chunk size matter for retrieval quality? | rag_notes.txt | YES | rag_notes.txt | 0.846 | 0.0008 |
| 3 | What is an embedding and why is it useful for search? | embeddings_basics.txt | YES | embeddings_basics.txt | 0.835 | 0.0007 |
| 4 | What does cosine similarity measure? | embeddings_basics.txt | YES | embeddings_basics.txt | 0.791 | 0.0009 |
| 5 | What is the tradeoff between TF-IDF and neural embedding models? | embeddings_basics.txt | YES | embeddings_basics.txt | 0.882 | 0.0007 |
| 6 | What does Reciprocal Rank Fusion do? | domain_archive.jsonl | YES | domain_archive.jsonl#1 | 0.993 | 0.0006 |
| 7 | Why is BM25 useful alongside vector search? | domain_archive.jsonl | YES | embeddings_basics.txt | 0.752 | 0.0006 |
| 8 | How does a cross-encoder re-ranker work? | domain_archive.jsonl | YES | domain_archive.jsonl#2 | 0.987 | 0.0007 |
| 9 | What FAISS index type supports fast approximate search on large corpora? | domain_archive.jsonl | YES | domain_archive.jsonl#0 | 0.973 | 0.0006 |

**Recall@3: 9/9 = 100.0%**  
**Avg retrieval time: 0.74 ms**

## Config: hybrid
- retrieval_mode=`hybrid`, use_reranker=`False`, top_k=`3`
- embedding backend: `lsa-fallback`

| # | Question | Expected source | Hit@k | Top retrieved source | Score | Retrieval time (s) |
|---|----------|------------------|-------|------------------------|-------|---------------------|
| 1 | What are the three core stages of a RAG pipeline? | rag_notes.txt | YES | rag_notes.txt | 0.033 | 0.0010 |
| 2 | Why does chunk size matter for retrieval quality? | rag_notes.txt | YES | rag_notes.txt | 0.033 | 0.0009 |
| 3 | What is an embedding and why is it useful for search? | embeddings_basics.txt | YES | embeddings_basics.txt | 0.033 | 0.0009 |
| 4 | What does cosine similarity measure? | embeddings_basics.txt | YES | embeddings_basics.txt | 0.033 | 0.0008 |
| 5 | What is the tradeoff between TF-IDF and neural embedding models? | embeddings_basics.txt | YES | embeddings_basics.txt | 0.033 | 0.0009 |
| 6 | What does Reciprocal Rank Fusion do? | domain_archive.jsonl | YES | domain_archive.jsonl#1 | 0.033 | 0.0008 |
| 7 | Why is BM25 useful alongside vector search? | domain_archive.jsonl | YES | embeddings_basics.txt | 0.033 | 0.0008 |
| 8 | How does a cross-encoder re-ranker work? | domain_archive.jsonl | YES | domain_archive.jsonl#2 | 0.033 | 0.0008 |
| 9 | What FAISS index type supports fast approximate search on large corpora? | domain_archive.jsonl | YES | domain_archive.jsonl#0 | 0.033 | 0.0009 |

**Recall@3: 9/9 = 100.0%**  
**Avg retrieval time: 0.87 ms**

## Config: hybrid+rerank
- retrieval_mode=`hybrid`, use_reranker=`True`, top_k=`3`
- embedding backend: `lsa-fallback`

| # | Question | Expected source | Hit@k | Top retrieved source | Score | Retrieval time (s) |
|---|----------|------------------|-------|------------------------|-------|---------------------|
| 1 | What are the three core stages of a RAG pipeline? | rag_notes.txt | YES | rag_notes.txt | 0.800 | 0.0011 |
| 2 | Why does chunk size matter for retrieval quality? | rag_notes.txt | YES | rag_notes.txt | 0.375 | 0.0008 |
| 3 | What is an embedding and why is it useful for search? | embeddings_basics.txt | YES | embeddings_basics.txt | 0.800 | 0.0010 |
| 4 | What does cosine similarity measure? | embeddings_basics.txt | YES | embeddings_basics.txt | 0.800 | 0.0008 |
| 5 | What is the tradeoff between TF-IDF and neural embedding models? | embeddings_basics.txt | YES | embeddings_basics.txt | 0.727 | 0.0007 |
| 6 | What does Reciprocal Rank Fusion do? | domain_archive.jsonl | YES | domain_archive.jsonl#1 | 0.500 | 0.0008 |
| 7 | Why is BM25 useful alongside vector search? | domain_archive.jsonl | YES | embeddings_basics.txt | 0.429 | 0.0008 |
| 8 | How does a cross-encoder re-ranker work? | domain_archive.jsonl | YES | domain_archive.jsonl#2 | 0.625 | 0.0009 |
| 9 | What FAISS index type supports fast approximate search on large corpora? | domain_archive.jsonl | YES | domain_archive.jsonl#0 | 0.545 | 0.0010 |

**Recall@3: 9/9 = 100.0%**  
**Avg retrieval time: 0.88 ms**

## Summary
| Config | Recall@k | Avg retrieval time (ms) | Embedding backend |
|--------|----------|---------------------------|--------------------|
| vector-only | 100.0% | 0.74 | lsa-fallback |
| hybrid | 100.0% | 0.87 | lsa-fallback |
| hybrid+rerank | 100.0% | 0.88 | lsa-fallback |