# System Metrics Report
Generated at: 2026-08-02 18:45:59
Documents folder: `sample_docs`

## Per-configuration metrics

### vector-only

**Chunking profile**
- chunk_size_target_chars: `400`
- overlap_chars: `50`
- num_documents: `6`
- num_chunks: `17`
- avg_chunk_length_chars: `315.5`
- min_chunk_length_chars: `221`
- max_chunk_length_chars: `395`

**Embedding model**
- backend: `lsa-fallback`
- requested_model: `all-MiniLM-L6-v2`
- dimension: `16`
- is_pretrained_neural_model: `False`

**Vector store**
- tool: `FAISS`
- index_type: `IndexFlatIP (exact cosine via normalized inner product)`
- num_vectors: `17`
- dimension: `16`

**Retrieval mode**: `vector`

**Reranker**
- enabled: `False`

**Generator (LLM) setup**
- llm_provider: `Anthropic`
- model: `claude-sonnet-4-6`
- max_tokens: `500`
- fallback_mode: `extractive (top passage) if ANTHROPIC_API_KEY is unset`

**Index build time**: `0.077s`

---

### hybrid

**Chunking profile**
- chunk_size_target_chars: `400`
- overlap_chars: `50`
- num_documents: `6`
- num_chunks: `17`
- avg_chunk_length_chars: `315.5`
- min_chunk_length_chars: `221`
- max_chunk_length_chars: `395`

**Embedding model**
- backend: `lsa-fallback`
- requested_model: `all-MiniLM-L6-v2`
- dimension: `16`
- is_pretrained_neural_model: `False`

**Vector store**
- tool: `FAISS`
- index_type: `IndexFlatIP (exact cosine via normalized inner product)`
- num_vectors: `17`
- dimension: `16`

**Retrieval mode**: `hybrid`

**Reranker**
- enabled: `False`

**Generator (LLM) setup**
- llm_provider: `Anthropic`
- model: `claude-sonnet-4-6`
- max_tokens: `500`
- fallback_mode: `extractive (top passage) if ANTHROPIC_API_KEY is unset`

**Index build time**: `0.006s`

---

### hybrid+rerank

**Chunking profile**
- chunk_size_target_chars: `400`
- overlap_chars: `50`
- num_documents: `6`
- num_chunks: `17`
- avg_chunk_length_chars: `315.5`
- min_chunk_length_chars: `221`
- max_chunk_length_chars: `395`

**Embedding model**
- backend: `lsa-fallback`
- requested_model: `all-MiniLM-L6-v2`
- dimension: `16`
- is_pretrained_neural_model: `False`

**Vector store**
- tool: `FAISS`
- index_type: `IndexFlatIP (exact cosine via normalized inner product)`
- num_vectors: `17`
- dimension: `16`

**Retrieval mode**: `hybrid`

**Reranker**
- backend: `lexical-overlap-fallback`
- requested_model: `cross-encoder/ms-marco-MiniLM-L-6-v2`
- is_pretrained_neural_model: `False`

**Generator (LLM) setup**
- llm_provider: `Anthropic`
- model: `claude-sonnet-4-6`
- max_tokens: `500`
- fallback_mode: `extractive (top passage) if ANTHROPIC_API_KEY is unset`

**Index build time**: `0.005s`

---

## Raw JSON (all configs)
```json
{
  "vector-only": {
    "chunking": {
      "chunk_size_target_chars": 400,
      "overlap_chars": 50,
      "num_documents": 6,
      "num_chunks": 17,
      "avg_chunk_length_chars": 315.5,
      "min_chunk_length_chars": 221,
      "max_chunk_length_chars": 395
    },
    "embedding_model": {
      "backend": "lsa-fallback",
      "requested_model": "all-MiniLM-L6-v2",
      "dimension": 16,
      "is_pretrained_neural_model": false
    },
    "vector_store": {
      "tool": "FAISS",
      "index_type": "IndexFlatIP (exact cosine via normalized inner product)",
      "num_vectors": 17,
      "dimension": 16
    },
    "retrieval_mode": "vector",
    "reranker": {
      "enabled": false
    },
    "build_time_seconds": 0.077,
    "generator": {
      "llm_provider": "Anthropic",
      "model": "claude-sonnet-4-6",
      "max_tokens": 500,
      "fallback_mode": "extractive (top passage) if ANTHROPIC_API_KEY is unset"
    }
  },
  "hybrid": {
    "chunking": {
      "chunk_size_target_chars": 400,
      "overlap_chars": 50,
      "num_documents": 6,
      "num_chunks": 17,
      "avg_chunk_length_chars": 315.5,
      "min_chunk_length_chars": 221,
      "max_chunk_length_chars": 395
    },
    "embedding_model": {
      "backend": "lsa-fallback",
      "requested_model": "all-MiniLM-L6-v2",
      "dimension": 16,
      "is_pretrained_neural_model": false
    },
    "vector_store": {
      "tool": "FAISS",
      "index_type": "IndexFlatIP (exact cosine via normalized inner product)",
      "num_vectors": 17,
      "dimension": 16
    },
    "retrieval_mode": "hybrid",
    "reranker": {
      "enabled": false
    },
    "build_time_seconds": 0.006,
    "generator": {
      "llm_provider": "Anthropic",
      "model": "claude-sonnet-4-6",
      "max_tokens": 500,
      "fallback_mode": "extractive (top passage) if ANTHROPIC_API_KEY is unset"
    }
  },
  "hybrid+rerank": {
    "chunking": {
      "chunk_size_target_chars": 400,
      "overlap_chars": 50,
      "num_documents": 6,
      "num_chunks": 17,
      "avg_chunk_length_chars": 315.5,
      "min_chunk_length_chars": 221,
      "max_chunk_length_chars": 395
    },
    "embedding_model": {
      "backend": "lsa-fallback",
      "requested_model": "all-MiniLM-L6-v2",
      "dimension": 16,
      "is_pretrained_neural_model": false
    },
    "vector_store": {
      "tool": "FAISS",
      "index_type": "IndexFlatIP (exact cosine via normalized inner product)",
      "num_vectors": 17,
      "dimension": 16
    },
    "retrieval_mode": "hybrid",
    "reranker": {
      "backend": "lexical-overlap-fallback",
      "requested_model": "cross-encoder/ms-marco-MiniLM-L-6-v2",
      "is_pretrained_neural_model": false
    },
    "build_time_seconds": 0.005,
    "generator": {
      "llm_provider": "Anthropic",
      "model": "claude-sonnet-4-6",
      "max_tokens": 500,
      "fallback_mode": "extractive (top passage) if ANTHROPIC_API_KEY is unset"
    }
  }
}
```